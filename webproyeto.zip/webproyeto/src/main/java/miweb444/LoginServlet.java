package miweb444;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

    private static final String FILE_PATH = "C:\\Users\\Kevin\\OneDrive\\Escritorio\\usuarios.txt";

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private boolean validarCredenciales(String correo, String contraseña) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(FILE_PATH));
            String hashedPassword = hashPassword(contraseña);
            
            for (String line : lines) {
                String[] parts = line.split(",");
                if (parts.length == 2 && parts[0].equals(correo) && parts[1].equals(hashedPassword)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String correo = request.getParameter("correo");
        String contraseña = request.getParameter("contra");

        // Validación básica
        if (correo == null || contraseña == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Faltan datos requeridos");
            return;
        }

        // Validar credenciales
        if (validarCredenciales(correo, contraseña)) {
            // Crear sesión y redirigir a la página principal
            HttpSession session = request.getSession();
            session.setAttribute("usuario", correo);
            response.sendRedirect("pagina-principal.jsp");
        } else {
            // Mostrar mensaje de error y redirigir de nuevo al formulario
            response.sendRedirect("inicio-sesion.jsp?error=1");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Login Servlet";
    }
}
