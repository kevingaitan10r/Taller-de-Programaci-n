package miweb444;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Enumeration;

public class miServlet extends HttpServlet {

    private static final String FILE_PATH = "C:\\Users\\Kevin\\OneDrive\\Escritorio\\hola.txt";

    public void PersistenciaArchivo(String infoAGrabar) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH, true))) { // 'true' para el modo append
            bw.write(infoAGrabar);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace(); // Mejor manejo de errores puede ser necesario
        }
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
         try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
        bw.write("Prueba de escritura");
        bw.newLine();
    } catch (IOException e) {
        e.printStackTrace();  // Esto imprimirá el error en los logs del servidor
    }

        // Guardar todos los parámetros del formulario en el archivo
        Enumeration<String> parameterNames = request.getParameterNames();
        while (parameterNames.hasMoreElements()) {
            String paramName = parameterNames.nextElement();
            String paramValue = request.getParameter(paramName);
            PersistenciaArchivo(paramName + ": " + paramValue);
        }

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Taller de Programacion</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Datos capturados</h1>");
            
            // Mostrar todos los parámetros capturados
            parameterNames = request.getParameterNames(); // Reinitialize enumeration
            while (parameterNames.hasMoreElements()) {
                String paramName = parameterNames.nextElement();
                String paramValue = request.getParameter(paramName);
                out.println("<h3>" + paramName + ": " + paramValue + "</h3>");
            }
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
